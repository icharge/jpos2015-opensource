<div class="panel panel-primary" style="margin: 10px">
  <div class="panel-heading">กำหนดคะแนนสะสม</div>
  <div class="panel-body">
    <form method="post" class="form-inline">
      <label style="width: 170px">จำนวนเงิน x บาท = 1 แต้ม</label>
      <input type="text" name="score" value="<?php echo $configSoftware->score; ?>" class="form-control" style="width: 100px" />
      <input type="submit" class="btn btn-primary" value="บันทึก" />
    </form>
  </div>
</div>