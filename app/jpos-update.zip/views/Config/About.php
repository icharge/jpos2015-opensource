<div class="panel panel-primary" style="margin: 10px">
    <div class="panel-heading">เกี่ยวกับโปรแกรม</div>
    <div class="panel-body">
        jPOS version 2013<br />
        ระบบบริหารงานร้านค้าปลีก ส่ง มินิมาร์ท ทุกรูปแบบ<br /><br />
        ออกแบบและพัฒนาโดย บ.ปิงปองซอฟต์ (คุณถาวร ศรีเสนพิลา)<br />
        โทร. 086 877 6053, mail: thekaroe@hotmail.com<br />
        www.pingpongsoft.com
    </div>
</div>