<span>
  <a href="index.php?r=Basic/Sale">
    ขายสินค้า
  </a>
</span>

<span>
  <a href="index.php?r=Basic/GetSale">
    รับคืนสินค้า
  </a>
</span>

<span>
  <a href="index.php?r=Basic/ManageBill">
    จัดการบิลขาย
  </a>
</span>

<span>
  <a href="index.php?r=Basic/Repair">
    ซ่อมแซมสินค้า
  </a>
</span>

<span>
  <a href="index.php?r=Basic/BillImport">
    รับเข้าสินค้า
  </a>
</span>

<span>
  <a href="index.php?r=Basic/BillDrop">
    ใบวางบิล
  </a>
</span>
