<?php if (Yii::app()->request->cookies['user_id'] != null): ?>

<?php
$user_id = Yii::app()->request->cookies['user_id']->value;
$user = User::model()->findByPk($user_id);
?>

<div class="row">
  <div class="col-md-12">
    <nav class="nav navbar-inverse" role="navigation" >
      <ul class="nav navbar-nav">
        <!-- menu -->
        <li class="dropdown">
          <a href="#" class="dropdown-toggle" data-toggle="dropdown">
            <i class="glyphicon glyphicon-home"></i>
            บันทึกประจำวัน
          </a>
          <ul class="dropdown-menu" role="menu">
            <li><a href="index.php?r=Basic/Sale">ขายสินค้า</a></li>
            <li><a href="index.php?r=Basic/GetSale">รับคืนสินค้า</a></li>
            <li><a href="index.php?r=Basic/ManageBill">จัดการบิลขาย</a></li>
            <li><a href="index.php?r=Basic/Repair">ซ่อมแซมสินค้า</a></li>
            <li><a href="index.php?r=Basic/GetRepair">รับซ่อมสินค้าจากภายนอก</a></li>
            <li><a href="index.php?r=Basic/BillImport">รับเข้าสินค้า</a></li>
            <li><a href="index.php?r=Basic/BillDrop">ใบวางบิล</a></li>
            <li><a href="index.php?r=Basic/BillQuotation">ใบเสนอราคา</a></li>
            <li><a href="index.php?r=Basic/CheckStock">เช็คสต็อก</a></li>
            <li class="divider"></li>
            <li><a href="index.php?r=BasicChangeProfile">เปลี่ยนรหัสผ่าน</a></li>
            <li><a href="index.php?r=Site/Home">พักหน้าจอ</a></li>
          </ul>
        </li>

        <!-- admin menu -->
        <?php if ($user->user_level == 'admin'): ?>
        <li class="dropdown">
          <a href="#" class="dropdown-toggle" data-toggle="dropdown">
            <i class="glyphicon glyphicon-list-alt"></i>
            รายงาน
          </a>
          <ul class="dropdown-menu" role="menu">
            <li><a href="index.php?r=Report/SalePerDay">ยอดขายประจำวัน</a></li>
            <li><a href="index.php?r=Report/SaleSumPerDay">สรุปยอดขายตามวัน</a></li>
            <li><a href="index.php?r=Report/SaleSumPerMonth">สรุปยอดขายตามเดือน</a></li>
            <li><a href="index.php?r=Report/SaleSumPerType">สรุปยอดขายตามประเภท</a></li>
            <li><a href="index.php?r=Report/SaleSumPerMember">สรุปยอดขายตามสมาชิก</a></li>
            <li><a href="index.php?r=Report/SaleSumPerEmployee">สรุปยอดขายตามพนักงาน</a></li>
            <li class="divider"></li>
            <li><a href="index.php?r=Report/ProductStock">รายงานสินค้า</a></li>
            <li><a href="index.php?r=Report/ReportAR">รายงานลูกหนี้</a></li>
            <li><a href="index.php?r=Report/ReportIR">รายงานเจ้าหนี้</a></li>
          </ul>
        </li>

        <li class="dropdown">
          <a href="#" class="dropdown-toggle" data-toggle="dropdown">
            <i class="glyphicon glyphicon-star"></i>
            ส่งเสริมการขาย
          </a>
          <ul class="dropdown-menu" role="menu">
            <li><a href="index.php?r=Support/SubPrice">กำหนดส่วนลด</a></li>
            <li><a href="index.php?r=Support/Score">กำหนดคะแนนสะสม</a></li>
          </ul>
        </li>

        <li class="dropdown">
          <a href="#" class="dropdown-toggle" data-toggle="dropdown">
            <i class="glyphicon glyphicon-cog"></i>
            ตั้งค่าพื้นฐาน
          </a>
          <ul class="dropdown-menu" role="menu">
            <li><a href="index.php?r=Config/Organization">ข้อมูลร้านค้า</a></li>
            <li><a href="index.php?r=Config/BranchIndex">คลังสินค้า/สาขา</a></li>
            <li><a href="index.php?r=Config/GroupProductIndex">ประเภทสินค้า</a></li>
            <li><a href="index.php?r=Config/ProductIndex">สินค้า</a></li>
            <li><a href="index.php?r=Config/FarmerIndex">ตัวแทนจำหน่าย</a></li>
            <li><a href="index.php?r=Config/MemberIndex">สมาชิกร้าน</a></li>
            <li><a href="index.php?r=Config/UserIndex">ผู้ใช้งานระบบ</a></li>
            <li><a href="index.php?r=Config/BillConfigIndex">ตั้งค่าการพิมพ์บิล</a></li>
            <li><a href="index.php?r=Config/DrawcashSetup">เงินในลิ้นชักวันนี้</a></li>
            <li><a href="index.php?r=Config/ConfigSoftware">ตั้งค่าบิล และสินค้าขั้นต่ำ</a></li>
            <li><a href="index.php?r=Config/ConfigTime">ตั้งค่าเวลาเครื่อง</a></li>
          </ul>
        </li>

        <li class="dropdown">
          <a href="#" class="dropdown-toggle" data-toggle="dropdown">
            <i class="glyphicon glyphicon-question-sign"></i>
            ช่วยเหลือ
          </a>
          <ul class="dropdown-menu" role="menu">
            <li><a href="index.php?r=Help/About">เกี่ยวกับเรา</a></li>
          </ul>
        </li>
        <?php endif; ?>
      </ul>
    </div>
  </div>
</div>

<?php
/*
$this->widget("application.extensions.mbmenu.MbMenu", array(
  "items" => array(
    array("label" => 'บันทึกประจำวัน', "items" => array(
      array("label" => "ขายสินค้า", "url" => array("Basic/Sale")),
      array("label" => "รับคืนสินค้า", "url" => array("Basic/GetSale")),
      array("label" => "จัดการบิลขาย", "url" => array("Basic/ManageBill")),
      array("label" => "ซ่อมแซมสินค้า", "url" => array("Basic/Repair")),
      array("label" => "รับซ่อมสินค้าภายนอก", "url" => array("Basic/GetRepair")),
      array("label" => "รับเข้าสินค้า", "url" => array("Basic/BillImport")),
      array("label" => "ใบวางบิล", "url" => array("Basic/BillDrop")),
      array("label" => "ใบเสนอราคา", "url" => array("Basic/BillQuotation")),
      array("label" => "เช็คสต็อก", "url" => array("Basic/CheckStock")),
      array("label" => "เปลี่ยนรหัสผ่าน", "url" => array("Basic/ChangeProfile")),
      array("label" => "พักหน้าจอ", "url" => array("Site/Home"))
    )),
    array("label" => "รายงาน", "visible" => (@$user->user_level == "admin"), "items" => array(
        array(
          "label" => "รายงานยอดขาย",
          "items" => array(
            array("label" => "ยอดขายประจำวัน", "url" => array("Report/SalePerDay")),
            array("label" => "สรุปยอดขายตามวัน", "url" => array("Report/SaleSumPerDay")),
            array("label" => "สรุปยอดขายตามเดือน", "url" => array("Report/SaleSumPerMonth")),
            array("label" => "สรุปยอดขายตามประเภท", "url" => array("Report/SaleSumPerType")),
            array("label" => "สรุปยอดขายตามสมาชิก", "url" => array("Report/SaleSumPerMember")),
            array("label" => "สรุปยอดขายตามพนักงาน", "url" => array("Report/SaleSumPerEmployee"))
          )
        ),
        array("label" => "รายงานสินค้า", "url" => array("Report/ProductStock")),
        array("label" => "รายงานลูกหนี้", "url" => array("Report/ReportAR")),
        array("label" => "รายงานเจ้าหนี้", "url" => array("Report/ReportIR"))
    )),
    array(
      "label" => "ส่งเสริมการขาย", "visible" => (@$user->user_level == "admin"), "items" => array(
         array("label" => "กำหนดส่วนลด", "url" => array("Support/SubPrice")),
         array('label' => 'กำหนดคะแนนสะสม', 'url' => array('Support/Score'))                                                                                        
      )
    ),
    array("label" => "ตั้งค่าพื้นฐาน", "visible" => (@$user->user_level == "admin"), "items" => array(
        array("label" => "ข้อมูลร้านค้า", "url" => array("Config/Organization")),
        array("label" => "คลังสินค้า/สาขา", "url" => array("Config/BranchIndex")),
        array("label" => "ประเภทสินค้า", "url" => array("Config/GroupProductIndex")),
        array("label" => "สินค้า", "url" => array("Config/ProductIndex")),
        array("label" => "ตัวแทนจำหน่าย", "url" => array("Config/FarmerIndex")),
        array("label" => "สมาชิกร้าน", "url" => array("Config/MemberIndex")),
        array("label" => "ผู้ใช้งานระบบ", "url" => array("Config/UserIndex")),
        array("label" => "ตั้งค่าการพิมพ์บิล", "url" => array("Config/BillConfigIndex")),
        array("label" => "เงินในลิ้นชักวันนี้", "url" => array("Config/DrawcashSetup")),
        array('label' => 'ตั้งค่าบิล และสินค้าขั้นต่ำ', 'url' => array('Config/ConfigSoftware')),
        array('label' => 'ตั้งค่าเวลาเครื่อง', 'url' => array('Config/ConfigTime'))
    )),
    array('label' => 'ช่วยเหลือ', 'visible' => (@$user->user_level == 'admin'), 'items' => array(
      array('label' => 'update โปรแกรม', 'url' => array('Help/UpdateSoftware')),
      array('label' => 'เกี่ยวกับเรา', 'url' => array('Help/About'))
    ))
)));
*/
?>

<?php endif; ?>
